//user schema for login
export class User{
    constructor(
        public username:string,
        public password:string
    ){}
}